package com.HP.TheCode1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class TheCode1Application {

	public static void main(String[] args) {
		SpringApplication.run(TheCode1Application.class, args);
	}
	
    
	
}

